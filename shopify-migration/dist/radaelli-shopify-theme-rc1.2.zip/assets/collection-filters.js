/**
 * Collection Page JS (Fase 02G). 2 responsabilidades, ambas justificadas
 * por lo que Liquid/CSS no pueden resolver solos:
 *
 * 1. Selector de columnas 2/3/4 (EXACT: réplica de catalog-toolbar.tsx
 *    real, param `vista`). Liquid renderiza en el servidor y NO tiene
 *    acceso a query params arbitrarios (a diferencia de `page`/
 *    `sort_by`/filtros nativos, que sí resuelve `collection`/`paginate`) --
 *    por eso esto es 100% client-side: lee `vista` de la URL al cargar,
 *    aplica la clase .grid--N, y al hacer click actualiza la URL
 *    (history.replaceState, sin recargar) + la clase, igual criterio que
 *    el real (router.replace, sin push a history, sin scroll jump).
 *
 * 2. Drawer de filtros mobile (bottom-sheet) -- mismo patrón que
 *    MobileMenuDrawer (header.js): Custom Element, focus trap, Escape,
 *    scroll lock, sin librería.
 */

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

/* ============================================================
   SELECTOR DE COLUMNAS (2/3/4) -- Custom Element
   ============================================================ */
class CollectionToolbar extends window.Radaelli.RadaelliElement {
  onConnect() {
    this.viewButtons = this.querySelectorAll("[data-view-button]");
    this.grid = document.querySelector("[data-collection-grid]");
    this.drawerTrigger = this.querySelector("[data-filter-drawer-trigger]");

    const params = new URLSearchParams(window.location.search);
    const defaultView = this.dataset.defaultView || "3";
    const currentView = params.get("vista") || defaultView;
    this.applyView(currentView, { updateUrl: false });

    this.viewButtons.forEach((button) => {
      button.addEventListener("click", () => {
        this.applyView(button.dataset.viewButton, { updateUrl: true });
      });
    });

    this.drawerTrigger?.addEventListener("click", () => {
      const drawer = document.getElementById("collection-filter-drawer");
      drawer?.open?.();
    });
  }

  applyView(columns, { updateUrl }) {
    if (!this.grid) return;
    this.grid.classList.remove("grid--2", "grid--3", "grid--4");
    this.grid.classList.add(`grid--${columns}`);

    this.viewButtons.forEach((button) => {
      const isActive = button.dataset.viewButton === String(columns);
      button.setAttribute("aria-pressed", String(isActive));
    });

    if (updateUrl) {
      const params = new URLSearchParams(window.location.search);
      const defaultView = this.dataset.defaultView || "3";
      if (String(columns) === defaultView) {
        params.delete("vista");
      } else {
        params.set("vista", String(columns));
      }
      const query = params.toString();
      const newUrl = query ? `${window.location.pathname}?${query}` : window.location.pathname;
      window.history.replaceState({}, "", newUrl);
    }
  }
}

window.Radaelli.defineElement("collection-toolbar", CollectionToolbar);

/* ============================================================
   FILTER DRAWER -- Custom Element (mismo patrón que MobileMenuDrawer)
   ============================================================ */
class FilterDrawer extends window.Radaelli.RadaelliElement {
  onConnect() {
    this.trigger = document.querySelector("[data-filter-drawer-trigger]");
    this.overlay = this.querySelector("[data-filter-drawer-overlay]");
    this.panel = this.querySelector(".filter-drawer__panel");
    this.closeButtons = this.querySelectorAll("[data-filter-drawer-close]");

    this.closeButtons.forEach((button) => button.addEventListener("click", () => this.close()));
    this.overlay?.addEventListener("click", () => this.close());
    this.addEventListener("keydown", (event) => this.handleKeydown(event));
  }

  open() {
    this.removeAttribute("hidden");
    requestAnimationFrame(() => {
      this.setAttribute("data-open", "true");
    });
    document.body.classList.add("has-filter-drawer-open");
    this.trigger?.setAttribute("aria-expanded", "true");
    const firstFocusable = this.panel?.querySelector(FOCUSABLE_SELECTOR);
    firstFocusable?.focus();
  }

  close() {
    this.removeAttribute("data-open");
    document.body.classList.remove("has-filter-drawer-open");
    this.trigger?.setAttribute("aria-expanded", "false");
    this.trigger?.focus();
    window.setTimeout(() => {
      if (!this.hasAttribute("data-open")) this.setAttribute("hidden", "");
    }, 220);
  }

  handleKeydown(event) {
    if (event.key === "Escape") {
      this.close();
      return;
    }
    if (event.key === "Tab") {
      this.trapFocus(event);
    }
  }

  trapFocus(event) {
    if (!this.panel) return;
    const focusable = this.panel.querySelectorAll(FOCUSABLE_SELECTOR);
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
}

window.Radaelli.defineElement("filter-drawer", FilterDrawer);
